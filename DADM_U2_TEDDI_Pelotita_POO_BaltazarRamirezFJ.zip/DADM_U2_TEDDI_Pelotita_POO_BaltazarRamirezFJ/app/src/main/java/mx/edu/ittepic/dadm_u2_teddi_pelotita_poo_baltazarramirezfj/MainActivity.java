package mx.edu.ittepic.dadm_u2_teddi_pelotita_poo_baltazarramirezfj;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setContentView(new Lorienzo(this));
    }
}
