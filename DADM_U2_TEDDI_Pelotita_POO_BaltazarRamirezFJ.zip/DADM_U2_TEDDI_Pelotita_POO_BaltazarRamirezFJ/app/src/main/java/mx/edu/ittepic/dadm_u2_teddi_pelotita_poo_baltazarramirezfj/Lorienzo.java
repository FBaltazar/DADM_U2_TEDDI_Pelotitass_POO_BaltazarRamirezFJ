package mx.edu.ittepic.dadm_u2_teddi_pelotita_poo_baltazarramirezfj;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class Lorienzo extends View
{
    Pelotin p1,p2,p3,p4,p5;
    public Lorienzo(Context context)
    {
        super(context);

        p1 = new Pelotin(350,1000,this, Color.BLUE,30);
        p2 = new Pelotin(500, 700,this,Color.RED,20);
        p3 = new Pelotin(700,900,this,Color.BLACK,80);
        p4 = new Pelotin(600,1000,this,Color.GREEN,100);
        p5 = new Pelotin(200,800,this,Color.YELLOW,60);


        p1.mover(10);
        p2.mover(7);
        p3.mover(4);
        p4.mover(1);
        p5.mover(5);

    }

    public void onDraw(Canvas c)
    {
        super.onDraw(c);

        Paint p = new Paint();

        p1.pintar(c,p);
        p2.pintar(c,p);
        p3.pintar(c,p);
        p4.pintar(c,p);
        p5.pintar(c,p);
    }
}
