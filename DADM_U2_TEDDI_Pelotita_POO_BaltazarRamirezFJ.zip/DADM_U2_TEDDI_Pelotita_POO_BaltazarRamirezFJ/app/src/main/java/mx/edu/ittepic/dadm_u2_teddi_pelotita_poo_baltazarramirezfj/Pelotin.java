package mx.edu.ittepic.dadm_u2_teddi_pelotita_poo_baltazarramirezfj;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.CountDownTimer;

public class Pelotin
{
    int color,desplazamientoX,desplazamientoY,r;
    float x,y;
    CountDownTimer timer;

    public Pelotin(int posx,int posy,final Lorienzo l,int c,int ra)
    {
        x = posx;
        y = posy;

        color = c;
        r = ra;
        timer = new CountDownTimer(1000,10) {
            @Override
            public void onTick(long millisUntilFinished)
            {
                x+=desplazamientoX;
                if (x >= l.getWidth() -80)
                {
                    desplazamientoX *= -1;
                }
                if (x <=80)
                {
                    desplazamientoX *= -1;
                }

                y += desplazamientoY;
                if (y >= l.getHeight()-80)
                {
                    desplazamientoY *= -1;
                }
                if (y <=80)
                {
                    desplazamientoY*= -1;
                }
                l.invalidate();
            }

            @Override
            public void onFinish()
            {
                start();
            }
        };
    }

    public void pintar(Canvas c, Paint p)
    {
        p.setColor(color);
        c.drawCircle(x,y,r,p);
    }

    public void mover(int desplaza)
    {
        desplazamientoX = desplaza;
        desplazamientoY = desplaza;

        timer.start();
    }

}
